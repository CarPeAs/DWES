
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div id="menu">
        <ul>
            <li>Home</li>
            <li class="cerrar-sesion"><a href="includes/logout.php">Cerrar sesión</a></li>
        </ul>
    </div>
    
    <form method="post" action="newUser2.php">

        <div>
            <label for="dni">DNI:</label>
            <input name="dni" type="text" id="dni"  required autofocus>
        </div>

        <div>
            <label for="name">Nombre:</label>
            <input name="name" type="text" id="name" required>
        </div>

        <div>
            <label for="adress">Dirección:</label>
            <input name="adress" type="text" id="adress" required>
        </div>

        <div>
            <label for="local">Localidad:</label>
            <input name="local" type="text" id="local" required>
        </div>

        <div>
            <label for="prov">Provincia:</label>
            <input name="prov" type="text" id="prov" required>
        </div>

        <div>
            <label for="phone">Teléfono:</label>
            <input name="phone" type="text" id="phone" pattern="[0-9]{9}" placeholder="Nº de 9 digitos" required>
        </div>

        <div>
            <label for="email">Email:</label>
            <input name="email" type="email" id="email" placeholder="ejemplo@email.com" required>
        </div>

        <div>
            <label for="clave">Contraseña:</label>
            <input name="clave" type="text" id="clave" required>
        </div>

        <div class="container">
            <input name="Enviar" value="Enviar datos" type="submit" class="button"><br>
        </div>
    </form>
    
   
    