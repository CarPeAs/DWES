<?php
$dni=$user->getDni();
$nombre=$user->getNombre();

//<?php echo $user->getNombre();  
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div id="menu">
        <ul>
            <li>Home</li>
            <li class="cerrar-sesion"><a href="includes/logout.php">Cerrar sesión</a></li>
        </ul>
    </div>
    

    <section>
        <h1>Bienvenido Usuario <?php echo $nombre ?></h1>
        <div id="tabla">
        <?php echo $user->getDatosInd($dni);  ?>
        </div>
    </section>

    <?php 
    include_once ("includes/articulos.php");
    $articulos= new Articulo();
        $matrizProductos = $articulos->getArticulos(); ?>

<table width='100%' border='2' cellspacing='4' cellpadding='3' style='font-size: 10pt' margin: 'auto';>

 
<caption>DATOS ARTICULOS</caption><br>

<thead>
    <tr>
        <th scope='col'>Codigo</th>
        <th scope='col'>Nombre</th>
        <th scope='col'>Descripción</th>
        <th scope='col'>Categoria</th>
        <th scope='col'>Precio</th>
        <th scope='col'>Imagen</th>
    </tr>
</thead><br>

   <?php foreach ($matrizProductos as $row):?>
        
        <tbody>
        <?php $i = 1; ?>
            <tr>
                <td><?php echo $row['codigo']?></td>
                <td><?php echo $row['nombre']?></td>
                <td><?php echo $row['descripcion']?></td>
                <td><?php echo $row['categoria']?></td>
                <td><?php echo $row['precio']?></td>
                <td><?php echo "<img src='{$row['imagen']}' width='95' height='95'>"?></td>
             </tr>
        <?php $i++; ?>
        <?php endforeach?>
        </tbody>     
</table>
    </section>
    
    <div class='container'>
        <a href='' class='boton'>Ordenar artículos por precio</a>
        <a href='' class='boton'>Ordenar artículos por categoria</a> 
    </div>
    
</body>
</html>