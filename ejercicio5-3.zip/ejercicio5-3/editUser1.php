<?php
/**FORMULARIO PARA EDITAR USUARIO*/

include 'includes/user.php';
include 'includes/user_session.php';


    $value = $_GET['id'];
    //$_SESSION['usuario']= $value;

    $user = new User();
   
    //$user->userRow($value);

    $arrayCliente=$user->userRow3($value);

   

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
<body>

    <form method="get" action="editUser2.php? id=<?php echo $value; ?>">
       
        <div>
            <label for="dni">DNI:</label>
            <input name="dni" type="text" id="usuario" value="<?php echo $value; ?>" readonly="readonly">
            <!--disabled si uso esto no puedo modificarlo si servia en el anterior proyecto-->
        </div>

        <div>
            <label for="name">Nombre:</label>
            <input name="name" type="text" id="name"value="<?php
            echo $arrayCliente[1]; ?>" required>
        </div>

        <div>
            <label for="adress">Dirección:</label>
            <input name="adress" type="text" id="adress" value="<?php
            echo $arrayCliente[2]; ?>" required>
        </div>

        <div>
            <label for="local">Localidad:</label>
            <input name="local" type="text" id="local" value="<?php
            echo $arrayCliente[3]; ?>" required>
        </div>

        <div>
            <label for="prov">Provincia:</label>
            <input name="prov" type="text" id="prov" value="<?php
            echo $arrayCliente[4]; ?>" required>
        </div>

        <div>
            <label for="phone">Teléfono:</label>
            <input name="phone" type="text" id="phone" value="<?php
            echo $arrayCliente[5]; ?>" pattern="[0-9]{9}" required>
        </div>

        <div>
            <label for="email">Email:</label>
            <input name="email" type="email" id="email"value="<?php
            echo $arrayCliente[6]; ?>" required>
        </div>

        <div>
            <label for="clave">Contraseña:</label>
            <input name="clave" type="text" id="clave"value="<?php
            echo $arrayCliente[7]; ?>" required>
        </div>

        <div>
            <label for="rol">Tipo Usuario:</label>
            <input name="rol" type="text" id="rol"value="<?php
            echo $arrayCliente[8]; ?>" readonly="readonly">
        </div>

        <!--
         if($arrayCliente[8]=="admin"){
            echo '<div>
            <label for="rol">Tipo Usuario:</label>
            <input name="rol" type="text" id="rol "value="'.echo $arrayCliente[8].' " readonly="readonly">
            </div>';
            
            }else{
                echo
                "<div>
                <label for='rol'>Tipo Usuario:</label>
                <input name='rol' type='text' id='rol' value='".$arrayCliente[8]."' >
            </div>";
            }
        -->
        
        <div class="container">
            <input name="Enviar" value="Modificar datos" type="submit" class="button">
        </div>

    </form>

    
</body>  
</html>
