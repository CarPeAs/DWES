<?php
/**FORMULARIO DE BUSQUEDA DE CLIENTE*/
include 'includes/user_session.php';
include 'includes/user.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

    <body>
        <form method="post" action="buscarCliente2.php">
            <div>
                <label for="dni">Introduzca DNI:<img src='img/search.png'></label>
                <input name="id" type="text" id="id" >
            </div>
        </form>
    </body>
    
</html>