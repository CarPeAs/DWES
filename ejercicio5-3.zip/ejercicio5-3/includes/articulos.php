<?php
include_once 'db.php';

class Articulo extends DB{

    private $codigo;
    private $nombre;
    private $descripcion;
    private $categoria;
    private $precio;
    private $imagen;

    //FUNCION PARA DAR DE ALTA ARTICULOS
    public function newArticulo($codigo,$nombre,$descripcion,$categoria,$precio,$imagen){
        $query = $this->connect()->prepare("INSERT INTO articulos VALUES (:codigo, :nombre, :descripcion, :categoria, :precio, :imagen)");
        $query -> execute(array(':codigo'=>$codigo,':nombre'=>$nombre, ':categoria'=>$categoria, 
        ':descripcion'=>$descripcion, ':precio'=>$precio,':imagen'=>$imagen));
    }

    //FUNCION PARA VER EL LISTADO DE ARTICULOS
    public function getArticulos(){
        $consulta = $this->connect()->query('SELECT * FROM articulos');
        $consulta->execute();

        while($filas=$consulta->fetch(PDO::FETCH_ASSOC)){
            $this->productos[]=$filas;
        }
        return $this->productos;
    }

    //FUNCION PARA BORRAR ARTICULOS
    public function borrarArticulo($codigo){
        $consulta = $this->connect()->prepare('DELETE FROM articulos WHERE codigo = :codigo');
        $consulta -> execute(array(":codigo"=>$codigo));
        print "Se ha eliminado".$consulta->rowCount()." fila/articulo de la base de datos";
        header("refresh:3; url=Location:listArticulos.php"); 
    }

    //FUNCION PARA EDITAR ARTICULOS
    public function editarArticulo($codigo,$nombre,$descripcion,$categoria,$precio,$imagen){
        $consulta = $this->connect()->prepare('UPDATE articulos SET nombre = :nombre,
        descripcion = :descripcion, categoria = :categoria, precio = :precio, imagen = :imagen WHERE codigo = :codigo');
        $consulta -> execute(array(":nombre"=>$nombre, ":descripcion"=>$descripcion,":categoria"=>$categoria, 
        ":precio"=>$precio, ":imagen"=>$imagen, ":codigo"=>$codigo));
    }

    //FUNCION VER DATOS DE 1 ARTICULO
    public function datoArticulo($value){
        $consulta = $this->connect()->query("SELECT * FROM articulos WHERE codigo = '$value'");
        $consulta->execute();
        //$arrayCliente = $cliente->fetch();
        return $consulta->fetch();
    }

    //FUNCION PARA ORDENAR ARTICULOS POR PRECIOS DESCENDENTE
    public function ordenarArticulosPre(){
        $consulta = $this->connect()->query('SELECT * FROM articulos ORDER BY precio DESC');
        $consulta->execute();

        while($filas=$consulta->fetch(PDO::FETCH_ASSOC)){
            $this->productos[]=$filas;
        }
        return $this->productos; 
    }

    //FUNCION PARA ORDENAR ARTICULOS POR CATEGORIAS
    public function ordenarArticulosCat(){
        $consulta = $this->connect()->query('SELECT * FROM articulos ORDER BY categoria');
        $consulta->execute();

        while($filas=$consulta->fetch(PDO::FETCH_ASSOC)){
            $this->productos[]=$filas;
        }
        return $this->productos; 
    }
    
}