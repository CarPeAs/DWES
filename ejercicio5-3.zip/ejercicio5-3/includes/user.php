<?php
include 'db.php';

class User extends DB{
    private $dni;
    private $nombre;
    private $username;
    private $direccion;
    private $localidad;
    private $provincia;
    private $telefono;
    private $email;
    private $clave;
    private $rol;

    public function userExists($user, $pass){
        
        $query = $this->connect()->prepare('SELECT * FROM clientes WHERE dni = :user AND clave = :pass');
        $query->execute(['user' => $user, 'pass' => $pass]);
        $row = $query->fetch();//PDO::FETCH_BOTH

        if($query->rowCount()){
            return true;
        }else{
            return false;
        }
    }

    public function setUser($user){
        $query = $this->connect()->prepare('SELECT * FROM clientes WHERE dni = :user');
        $query->execute(['user' => $user]);
        
        foreach ($query as $currentUser) {
            $this->dni = $currentUser['dni'];
            $this->nombre = $currentUser['nombre'];
            $this->username = $currentUser['nombre'];
            $this->direccion = $currentUser['direccion'];
            $this->localidad = $currentUser['localidad'];
            $this->provincia = $currentUser['provincia'];
            $this->telefono = $currentUser['telefono'];
            $this->email = $currentUser['email'];
            $this->rol = $currentUser['rol'];
            $this->clave = $currentUser['clave'];
        }
    }


    public function getDni(){
        return $this->dni;
    }

    public function getNombre(){
        return $this->nombre;
    }

    public function getClave(){
        return $this->clave;
    }

    public function getRol(){
        return $this->rol;
    }

    public function getDatos2(){
        return $this->nombre.' '.$this->clave.' '.$this->rol; 
    }


    public function getDatos(){
        $query = $this->connect()->query('SELECT * FROM clientes');
        $query->execute();
    
        echo "<table width='100%'> \n";

    echo 
    "<caption>DATOS USUARIOS</caption><br>
    
    <thead>
        <tr>
            <th scope='col'>DNI</th>
            <th scope='col'>Nombre</th>
            <th scope='col'>Dirección</th>
            <th scope='col'>Localidad</th>
            <th scope='col'>Provincia</th>
            <th scope='col'>Telefono</th>
            <th scope='col'>Email</th>
            <th scope='col'>Contraseña</th>
            <th scope='col'>Tipo Usuario</th>
            <th id='editar'>Editar</th>
            <th id='borrar'>Borrar</th>
        </tr>
    </thead><br>";

       while ($row = $query->fetch()){
            echo "
            <tbody>
                <tr>
                    <td>$row[0]</td>
                    <td>$row[1]</td>
                    <td>$row[2]</td>
                    <td>$row[3]</td>
                    <td>$row[4]</td>
                    <td>$row[5]</td>
                    <td>$row[6]</td>
                    <td>$row[7]</td>
                    <td>$row[8]</td>
                    <td><a href='editUser1.php?id=".$row[0]."'><img src='img/edit.png'></td>
                    <td><a href='borrarUser1.php?id=".$row[0]."'><img src='img/delete.png'></a></td>
                 </tr>
             </tbody>";
        } 

    echo "</table>\n";
    }

    public function getDatosInd($value){
        $query = $this->connect()->query("SELECT * FROM clientes WHERE dni = '$value'");
        $query->execute();
    
        echo "<table width='100%'> \n";

    echo 
    "<caption>DATOS USUARIO</caption><br>
    
    <thead>
        <tr>
        <th scope='col'>DNI</th>
        <th scope='col'>Nombre</th>
        <th scope='col'>Dirección</th>
        <th scope='col'>Localidad</th>
        <th scope='col'>Provincia</th>
        <th scope='col'>Telefono</th>
        <th scope='col'>Email</th>
        <th scope='col'>Contraseña</th>
        <th scope='col'>Tipo Usuario</th>
        <th id='editar'>Editar</th>
        <th id='borrar'>Borrar</th>
        </tr>
    </thead><br>";

       while ($row = $query->fetch()){
            echo "
            <tbody>
                <tr>
                    <td>$row[0]</td>
                    <td>$row[1]</td>
                    <td>$row[2]</td>
                    <td>$row[3]</td>
                    <td>$row[4]</td>
                    <td>$row[5]</td>
                    <td>$row[6]</td>
                    <td>$row[7]</td>
                    <td>$row[8]</td>
                    <td><a href='editUser1.php?id=".$row[0]."'><img src='img/edit.png'></td>
                    <td><a href='borrarUser3.php?id=".$row[0]."'><img src='img/delete.png'></a></td>
                 </tr>
             </tbody>";
        } 

    echo "</table>\n";
    }

    public function getDatosBorrar($value){
        $query = $this->connect()->query("SELECT * FROM clientes WHERE dni = '$value'");
        $query->execute();
    
        echo "<table> \n";

    echo 
    "<caption>DATOS CLIENTE</caption><br>
    
    <thead>
        <tr>
        <th scope='col'>DNI</th>
        <th scope='col'>Nombre</th>
        <th scope='col'>Dirección</th>
        <th scope='col'>Localidad</th>
        <th scope='col'>Provincia</th>
        <th scope='col'>Telefono</th>
        <th scope='col'>Email</th>
        <th scope='col'>Contraseña</th>
        <th scope='col'>Tipo Usuario</th>
        </tr>
    </thead><br>";

       while ($row = $query->fetch()){
            echo "
            <tbody>
                <tr>
                    <td>$row[0]</td>
                    <td>$row[1]</td>
                    <td>$row[2]</td>
                    <td>$row[3]</td>
                    <td>$row[4]</td>
                    <td>$row[5]</td>
                    <td>$row[6]</td>
                    <td>$row[7]</td>
                    <td>$row[8]</td>
                 </tr>
             </tbody>";
        } 

    echo "</table>\n";
    }



    public function newUser($dni,$name,$dir,$loc,$prov,$tel,$mail,$pwd,$rol){
        //$pwd_hash = password_hash($pwd,PASSWORD_DEFAULT, ['cost'=>5]);
        $query = $this->connect()->prepare('INSERT INTO clientes VALUES (:dni, :nombre, :direccion, :localidad, :provincia, :telefono, :email, :clave, :rol)');
        $query -> execute(array(":dni"=>$dni, ":nombre"=>$name, ":direccion"=>$dir,":localidad"=>$loc, 
        ":provincia"=>$prov, ":telefono"=>$tel, ":email"=>$mail, ":clave"=>$pwd, ":rol"=>$rol));
    }


    public function borrarUser($user){
        $query = $this->connect()->prepare('DELETE FROM clientes WHERE dni = :usuario');
        $query -> execute(array(":usuario"=>$user));
        print "Se ha eliminado".$query->rowCount()." fila(s) de la base de datos";
        header("refresh:3; url=Location:index.php"); 
    }

    //FUNCIÓN PARA QUE UN USUARIO BORRE SUS PROPIOS DATOS
    public function borrarUser2($user){
        $query = $this->connect()->prepare('DELETE FROM clientes WHERE dni = :usuario');
        $query -> execute(array(":usuario"=>$user));
        print "Se ha eliminado su cuenta".$query->rowCount()." de la base de datos";
        header("refresh:3; url=Location:logout.php"); 
    }

    public function editarUser($dni,$name,$dir,$loc,$prov,$tel,$mail,$pwd,$rol){
        $query = $this->connect()->prepare('UPDATE clientes SET nombre = :nombre, direccion = :direccion,
        localidad = :localidad, provincia = :provincia, telefono = :telefono, email = :email, 
        clave = :clave, rol = :rol WHERE dni = :usuario');
        $query -> execute(array(":nombre"=>$name, ":direccion"=>$dir,":localidad"=>$loc, 
        ":provincia"=>$prov, ":telefono"=>$tel, ":email"=>$mail, ":clave"=>$pwd, ":rol"=>$rol, ":usuario"=>$dni));
    }

    public function userRow($user){
        $query = $this->connect()->prepare('SELECT * FROM clientes WHERE dni = :user');
        $query->execute(['user' => $user]);
        
        foreach ($query as $currentUser) {
            echo
            " <html>
            <body>
            <form method='post' action='editUser2.php' id=$user>
          
               <div>
                   <label for='dni'>Usuario:</label>
                   <input name='dni' type='text' id='dni' disabled value=$currentUser[0]>
               </div>
   
               <div>
                   <label for='name'>Clave:</label>
                   <input name='name' type='text' id='name' value=$currentUser[1]>
               </div>
   
               <div>
                   <label for='adress'>Rol:</label>
                   <input name='adress' type='text' id='adress' value=$currentUser[2]>
               </div>
   
               <div class='container'>
               <input name='Enviar' value='Modificar datos' type='submit' class='button'>
           </div>
           </body>
           </form>
           </html>";
        }
    }


    public function userRow2($value){
        $query = $this->connect()->prepare("SELECT * FROM clientes WHERE dni = '$value'");
        $query->execute();
        $row = $query->fetch();

        print
         " <form method='post' action='editUser2.php' id=$value >
       
            <div>
                <label for='dni'>Usuario:</label>
                <input name='dni' type='text' id='dni' disabled value=$row[0]>
            </div>

            <div>
                <label for='name'>Clave:</label>
                <input name='name' type='text' id='name' value=$row[1]>
            </div>

            <div>
                <label for='adress'>Rol:</label>
                <input name='adress' type='text' id='adress' value=$row[2]>
            </div>

            <div class='container'>
            <input name='Enviar' value='Modificar datos' type='submit' class='button'>
        </div>
        
        </form>";

    }

    public function userRow3($value){
        $cliente = $this->connect()->query("SELECT * FROM clientes WHERE dni = '$value'");
        $cliente->execute();
        //$arrayCliente = $cliente->fetch();
        return $cliente->fetch();
    }

    //FUNCIÓN QUE DEVUELVE LOS DATOS DE USUARIOS POR NOMBRE DESCENDENTE
    public function getDatosDesc(){
        $consulta = $this->connect()->query('SELECT * FROM clientes ORDER BY nombre DESC');
        $consulta->execute();

        while($filas=$consulta->fetch(PDO::FETCH_ASSOC)){
            $this->usuarios[]=$filas;
        }
        return $this->usuarios; 
    }

    //FUNCIÓN QUE DEVUELVE LOS DATOS DE USUARIOS POR NOMBRE ASCENDENTE
    public function getDatosAsc(){
        $consulta = $this->connect()->query('SELECT * FROM clientes ORDER BY nombre');
        $consulta->execute();

        while($filas=$consulta->fetch(PDO::FETCH_ASSOC)){
            $this->usuarios[]=$filas;
        }
        return $this->usuarios; 
    }


    //FUNCIÓN QUE DEVUELVE LOS DATOS DE CONTRASEÑA
    public function userPassword($dni,$email){
        $cliente = $this->connect()->query("SELECT * FROM clientes WHERE dni = '$dni' AND email = '$email'");
        $cliente->execute();
        $arrayCliente = $cliente->fetch();
        return $arrayCliente[7];
    }
    
    
}//PARENTESIS FINAL NO TOCAR

?>