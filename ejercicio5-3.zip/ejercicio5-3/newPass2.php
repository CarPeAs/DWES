<?php

include 'includes/user_session.php';
include 'includes/user.php';

$dni=$_REQUEST['dni'];
$mail=$_REQUEST['email'];
$user = new User();

if(!empty($dni) && !empty($mail)) {

    echo "<h2>Esta es su contraseña</h2>";
    echo $user->userPassword($dni,$mail);
    echo   "<div class='container'>
            <a href='index.php' class='button' >Volver a login</a>
        </div>";

    }else{
        echo "
        <h2>No coincide el mail y dni</h2>
            <div class='container'>
                <a href='newPass1.php' class='button'>Volver</a>
            </div>";
    }

    