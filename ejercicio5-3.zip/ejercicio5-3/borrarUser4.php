<?php
/**CONTROL DE BORRADO DEL PROPIO USUARIO*/
include_once 'includes/user_session.php';
include_once 'includes/user.php';



$value = $_GET['id'];
$user = new User();

//$user->borrarUser($value)
try{
    $user->borrarUser2($value);
    echo "<h2>Sus datos $value han sido borrados correctamente</h2>";
    header("refresh:2; url=includes/logout.php");
        
}catch(PDOException $e){
    echo "No se pudo borrar al usuario". $e->getMessage();
    echo "
    <div class='container'>
        <a href='index.php' class='button' >Volver a clientes</a>
    </div>";

}