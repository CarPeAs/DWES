<?php
/**CONTROL DE BORRADO DE CLIENTE*/
include_once 'includes/user_session.php';
include_once 'includes/user.php';



$value = $_GET['id'];
$user = new User();

//$user->borrarUser($value)
try{
    $user->borrarUser($value);
    echo "<h2>Los datos del cliente $value han sido borrados correctamente</h2>";
    header("refresh:2; url=index.php");
        
}catch(PDOException $e){
    echo "No se pudo borrar al usuario". $e->getMessage();
    echo "
    <div class='container'>
        <a href='index.php' class='button' >Volver a clientes</a>
    </div>";

}







?>