<?php
include 'includes/user_session.php';
include 'includes/user.php';
include 'includes/articulos.php';


$codigo = $_POST['codigo'];
$nombre = $_POST['nombre'];
$descripcion = $_POST['descripcion'];
$categoria = $_POST['categoria'];
$precio = $_POST['precio'];
$nombre_archivo = $_FILES['imagen']['name'];
$ruta = "img/" . $nombre_archivo;
$temp = $_FILES['imagen']['tmp_name'];


if($_FILES['imagen']['size'] < 600000){//COMPROBAR TAMAÑO IMAGEN MENOR A 600KB

    if (exif_imagetype($temp) == IMAGETYPE_GIF || exif_imagetype($temp) == IMAGETYPE_PNG || exif_imagetype($temp) ==IMAGETYPE_JPEG ) {
    //COMPROBAR TIPO IMAGEN SOLO PNG,GIF Y JPEG

        list($ancho, $alto, $tipos, $atributos) = getimagesize($temp);
        echo "Ancho original de imagen: " . $ancho . "<br>";
        echo "Alto original de imagen: " . $alto . "<br>";
        echo "Tipo :" . $tipos . "<br>";
        echo "Atributos:" .$atributos;
        
        if (move_uploaded_file($temp,$ruta)) {
            $articulo= new Articulo();
            echo '<div><b>Se ha subido correctamente la imagen.</b></div>';
            
            //Mostramos la imagen subida con las medidas dadas por el usuario
            echo '<p><img src="img/'.$nombre_archivo.'"></p>';
            $articulo->newArticulo($codigo,$nombre,$descripcion,$categoria,$precio,$ruta);
            echo "¡Registro creado satisfactoriamente!";

            //Enlace al listado de productos subidos
            echo "
            <div class='container'>
                <a href='index.php' class='boton'>Volver</a>
            </div>";
        
            //Enlace al index
            echo "
            <div class='container'>
                <a href='addProducto1.php' class='boton'>Dar de alta otro artículo</a>
            </div>";
            
        }
        else {
        //Si no se ha podido subir la imagen, mostramos un mensaje de error
        echo '<div><b>Ocurrió algún error al subir el fichero. No pudo guardarse.</b></div>';
        }


        } else{//COMPROBAR TIPO IMAGEN
        echo 'Los formatos de imagen permitidos son GIF, PNG y JPEG <br>';
        
        echo "
        <div class='container'>
        <a href='index.php' class='boton'>Volver al formulario</a>
        </div>";
    }

} else{//COMPROBAR TAMAÑO IMAGEN
    echo "Debe subir una imagen menor a 600kBytes <br>";

    echo "
    <div class='container'>
        <a href='index.php' class='boton'>Volver al formulario</a>
    </div>";
}



   


?>