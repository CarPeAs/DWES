<?php

/**FORMULARIO PARA BORRAR CLIENTE*/
include 'includes/user.php';
include 'includes/user_session.php';

$value = $_GET['id'];//id en la otra base de datos

$user = new User();

echo "<h2>Estas seguro que quieres eliminar al usuario: </h2>";

$user->getDatosBorrar($value);

    echo "
        <a href='borrarUser2.php?id=".$value."' class='button'>Eliminar</a>
    
        <a href='index.php' class='button'> Volver </a>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
  
    
    
</body>
</html>
