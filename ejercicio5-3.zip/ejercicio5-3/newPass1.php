<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
  
    <form method="post" action="newPass2.php">

        <div>
            <label for="dni">DNI:</label>
            <input name="dni" type="text" id="dni" >
        </div>

        <div>
            <label for="email">Email:</label>
            <input name="email" type="email" id="email" >
        </div>

    

        <div class="container">
            <input name="Enviar" value="Enviar datos" type="submit" class="button"><br>
        </div>
    </form>
    
   
    