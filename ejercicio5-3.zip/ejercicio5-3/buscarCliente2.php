<?php
/**CONTROL DE BUSQUEDA CLIENTE*/
include 'includes/user_session.php';
include 'includes/user.php';

$dni = $_REQUEST['id'];
$user = new User();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home</title>
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>

<div id="menu">
        <ul>
            <li>Home</li>
            <li class="cerrar-sesion"><a href="includes/logout.php">Cerrar sesión</a></li>
        </ul>
    </div>
    <section>
        <h2>Los datos del usuario son:</h2>
        <div id="tabla">
        <?php echo $user->getDatosInd($dni);  ?>
        </div>
    </section>
    <br>
    <div class='container'>
                <a href='index.php' class='button' >Volver</a>
    </div>";
    
</html>