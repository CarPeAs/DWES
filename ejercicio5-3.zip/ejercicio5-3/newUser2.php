<?php
/**CONTROL DE ALTA NUEVO CLIENTE*/
//dni de pruebas 11111111H 22222222J 33333333P 44444444A 55555555K 66666666Q

include 'includes/user_session.php';
include 'includes/user.php';

$dni=strtoupper($_REQUEST['dni']);//$_REQUEST['dni'];
$nom=$_REQUEST['name'];
$dir=$_REQUEST['adress'];
$loc=$_REQUEST['local'];
$pro=$_REQUEST['prov'];
$tel=$_REQUEST['phone'];
$mail=$_REQUEST['email'];
$clave=$_REQUEST['clave'];
$rol='user';

if(!empty($dni) && !empty($nom) && !empty($dir) && !empty($loc) && !empty($pro) && !empty($tel) && !empty($mail) && !empty($clave)) {//comprobar que todos los datos estén rellenados
    
    $letras = substr($dni, -1);
    $numeros = substr($dni, 0, -1);
      
    if (substr("TRWAGMYFPDXBNJZSQVHLCKE", $numeros%23, 1) == $letras && strlen($letras) == 1 && strlen ($numeros) == 8 ){//compruebo DNI
        
        // Compruebo el email es obligatorio y ha de tener formato adecuado
        if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
            echo"<h3>El formato de email no es correcto</h3>";
       
            echo " <div class='container'>
             <a href='newUser1.php' class='boton'>Volver</a>
            </div>";
        }else{
            $user = new User();
            try {
                $user->newUser($dni,$nom,$dir,$loc,$pro,$tel,$mail,$clave,$rol);
                echo "<h2>Los datos han sido introducidos satisfactoriamente</h2>";
                header("refresh:2; url=index.php");  
            } catch (PDOException $e) {
                if ($e->getCode() == '23000')
                    echo "<h2>Ya existe ese DNI en la Base de Datos</h2>";
                    echo "
                    <div class='container'>
                        <a href='index.php' class='boton'>Volver</a>
                    </div>";  
            }
        }

    }else{
            
        echo "
        <h3>Debes escribir un DNI valido</h3>
        <div class='container'>
            <a href='newUser1.php' class='button'>Volver</a>
        </div>
        ";
    }
      
        }else {
            echo "
                <h2>Debes rellenar todos los campos del formulario</h2>
                <div class='container'>
                    <a href='newUser1.php' class='boton'>Volver</a>
                </div>";
            }
            
          
          
  

        
?>

