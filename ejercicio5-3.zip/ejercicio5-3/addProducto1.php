<?php
include 'includes/user_session.php';
include 'includes/user.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form name="formadd" method="post" action="addProducto2.php" enctype="multipart/form-data">
<center><table border=0 CELLPADDING=10>
<tr><u style="color:rgba(0, 134, 124, 1)"><h1>Añade el producto y sus caracteristicas</h1></u></tr>
<tr>
<td width="200" height="50">Nombre: 
<input name="nombre" type="text" id="nombre" maxlength="255" size="40" required></td>
<td width="200" height="50">Codigo: 
<input name="codigo" type="text" id="codigo" maxlength="8" size="40" required pattern="[A-Za-z]{3}[0-9]{1,5}"></td>
<td width="200" height="50">Precio:<br>
<input name="precio" id="precio" type="number" value="10.00" step="0.01" min="1" max="9999" size="50"></td></tr>


<tr><td><SELECT style="width: 170;" NAME="categoria" id="categoria" required>
<OPTGROUP LABEL="Tipo de producto">
<option value="Camiseta" selected>Camiseta</option>
<option value="Pantalon">Pantalon</option>
<option value="Zapatos">Zapatos</option>
<option value="Otros">Otros</option>
</select><br></td>
<td width="200" height="50"><INPUT name="imagen" id="imagen" TYPE="FILE" accept=".jpg, .jpeg, .png" required></td></tr>
<tr><td colspan=2><TEXTAREA placeholder="Añade una descripción obligatoriamente" name="descripcion" id="descripcion" ROWS=5 COLS=40 required></TEXTAREA></td></tr>
<tr><td colspan=2 width="200" height="75"><input name="Borrar" value="Limpiar" type="reset">
&nbsp;&nbsp;&nbsp;<input type="submit" name="enviar" value="Enviar"></td></tr>
</table>
</form>
</body>
</html>
