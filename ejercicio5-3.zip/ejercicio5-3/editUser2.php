<?php
/**CONTROL DE EDITAR ANTIGUO CLIENTE*/
include 'includes/user_session.php';
include 'includes/user.php';


/*$nombre = $_GET['dni'];
//$_SESSION['usuario'] = $nombre;
$clave = $_REQUEST['name'];
$rol = $_REQUEST['adress'];*/


$dni=$_GET['dni'];
$nom=$_REQUEST['name'];
$dir=$_REQUEST['adress'];
$loc=$_REQUEST['local'];
$pro=$_REQUEST['prov'];
$tel=$_REQUEST['phone'];
$mail=$_REQUEST['email'];
$clave=$_REQUEST['clave'];
$rol=$_REQUEST['rol'];
$user = new User();


if(!empty($dni) && !empty($nom) && !empty($dir) && !empty($loc) && !empty($pro) && !empty($tel) && !empty($mail) && !empty($clave) && !empty($rol)) {
    
    if(!filter_var($mail, FILTER_VALIDATE_EMAIL)){
        echo"<h3>El formato de email no es correcto</h3>";
   
        echo " <div class='container'>
            <a href='editUser1.php?id=".$dni."' class='button'>Volver</a>
        </div>";

    }else{
        $user->editarUser($dni,$nom,$dir,$loc,$pro,$tel,$mail,$clave,$rol);

        echo "<h2>Los datos han sido modificados satisfactoriamente</h2>";
                header("refresh:2; url=index.php");  
    }

    }else{
        echo "
        <h2>Debes rellenar todos los datos, vuelve al formulario</h2>
            <div class='container'>
                <a href='editUser1.php?id=".$dni."' class='button'>Volver</a>
            </div>";
    }


?>
